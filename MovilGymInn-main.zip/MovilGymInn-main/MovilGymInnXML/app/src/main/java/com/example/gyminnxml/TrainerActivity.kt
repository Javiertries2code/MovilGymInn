package com.example.gyminnxml

import androidx.appcompat.app.AppCompatActivity

class TrainerActivity :  AppCompatActivity() {


}